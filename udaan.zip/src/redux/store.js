import { createStore, applyMiddleware } from 'react'
import logger from 'redux-logger'
import rootReducer from './root-reducer'

const middleware = [];

if (process.env.NODE_ENV === 'development') {
    middleware.push(logger)
}
export const store = createStore(rootReducer, applyMiddleware(...middleware))





// const persistConfig={
//     key: 'root',
//     storage,
//     whitelist:['cart','directory']
// }
// export default  persistReducer(persistConfig,rootReducer)