
import React from 'react';
import CrashCardData from './pages/CrashCardData/CrashCardData'
import CrashInfo from './componnets/crashInfo/crashInfo'
import{BrowserRouter as Route,Switch} from 'react-router-dom'
import './App.css';

function App() {
  
  return (
    <div >
      <Switch>
      <Route exact path='/'component={CrashCardData}/>
      <Route exact path='/crshinfo'component={CrashInfo}/>
      </Switch>
    </div>
  );
}

export default App;
