import React, { useEffect, useState } from 'react';
import Pagination from '../../componnets/Pagination/pagination';
import CrashCard from '../../componnets/CrashCard/crashCard';
import axios from 'axios';
const CrashCardData = () => {
    const [loading, setLoading] = useState(false);
    const [currentPage, setCurrentPage] = useState(1);
    const [postsPerPage, setPostsPerPage] = useState(10);
    const [Date,setDate]=useState('')
    useEffect(() => {
        setLoading(true)
        getAllData();
        setLoading(false)
    }, [])

    const [crashData, setCrashdata] = useState('')
    const onDateChange=(e) => {
        setDate(e.target.value)
    }
    const getAllData = async () => {
        let data = await axios.get('https://data.cityofnewyork.us/resource/h9gi-nx95.json')
        try {
            if (data) {
                setCrashdata(data)
            }
        } catch (error) {
            console.log(error)
        }
    }
    const getfilteredDateData = async (date) => {
        let data = await axios.get(`https://data.cityofnewyork.us/resource/h9gi-nx95.json?crash_date=${date}`)
        try {
            if (data) {
                setCrashdata(data)
            }
        } catch (error) {
            console.log(error)
        }
    }

    const indexOflastCrash = currentPage * postsPerPage;
    const indexOfFirstCrash = indexOflastCrash * postsPerPage
    const currentCrash = crashData.slice(indexOfFirstCrash, indexOflastCrash)

    return (
        <div>
            {currentCrash.map((crash, key) => (<CrashCard key={key} crash={crash} loading={loading} />))}
            <Pagination crashperPage={postsPerPage} totalCrash={crashData.length} />
            <input placeholder="date" value={Date} name="date"onChange={onDateChange}>Click </input>
            <button onClick={getfilteredDateData}></button>
        </div>
    )
}

export default CrashCardData
