import React from 'react'

function pagination({ crashperPage, totalCrash }) {
    const pageNumbers = [];
    for (let i = 1; i <= Math.ceil(totalCrash / crashperPage); i++) {
        pageNumbers.push(i)
    }
    return (
        <nav>
            <ul>
                {pageNumbers.map(number => (
                    <li key={number}>
                        <a  href="!#">
                            {number}
                        </a>
                    </li>
                ))}
            </ul>
        </nav>
    )
}

export default pagination
