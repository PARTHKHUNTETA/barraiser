import React from 'react'
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import Typography from '@mui/material/Typography';
import { CardActionArea } from '@mui/material';
function crashCard({card}) {
    return (
        <div>
            <Card sx={{ maxWidth: 345 }}>
                <CardActionArea>
                    <CardContent>
                        <Typography gutterBottom variant="h5" component="div">
                            Vehicle TypeA
                        </Typography>
                        <Typography variant="body2" color="text.secondary">
                            {crash.vehicle_type_code1}
                        </Typography>
                        <Typography gutterBottom variant="h5" component="div">
                            Vehicle TypeB
                        </Typography>
                        <Typography variant="body2" color="text.secondary">
                            {crash.vehicle_type_code1}
                        </Typography>
                        <Typography gutterBottom variant="h5" component="div">
                            Crash Date
                        </Typography>
                        <Typography variant="body2" color="text.secondary">
                            {crash.vehicle_type_code1}
                        </Typography>
                        <Typography gutterBottom variant="h5" component="div">
                            Crash Time
                        </Typography>
                        <Typography variant="body2" color="text.secondary">
                            {crash.vehicle_type_code1}
                        </Typography>
                    </CardContent>
                </CardActionArea>
            </Card>
        </div>
    )
}

export default crashCard
