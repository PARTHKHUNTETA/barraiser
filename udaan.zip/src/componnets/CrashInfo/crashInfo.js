import React from 'react'
import Typography from '@mui/material/Typography';
function crashInfo() {
    return (
        <div>
            <Typography gutterBottom variant="h5" component="div">
                Vehicle TypeA
            </Typography>
            <Typography variant="body2" color="text.secondary">
                {crash.collision_id}
            </Typography>
            <Typography gutterBottom variant="h5" component="div">
                Contribuiting factor Vehicle 1
            </Typography>
            <Typography variant="body2" color="text.secondary">
                {crash.contributing_factor_vehicle_1}
            </Typography>
            <Typography gutterBottom variant="h5" component="div">
                Contribuiting factor Vehicle 2
            </Typography>
            <Typography variant="body2" color="text.secondary">
                {crash.contributing_factor_vehicle_2}
            </Typography>
            <Typography gutterBottom variant="h5" component="div">
                Crash date
            </Typography>
            <Typography variant="body2" color="text.secondary">
                {crash.crash_date}
            </Typography>
            <Typography gutterBottom variant="h5" component="div">
                Crash time
            </Typography>
            <Typography variant="body2" color="text.secondary">
                {new Date(crash.crash_time)}
            </Typography>
            <Typography gutterBottom variant="h5" component="div">
                Street Name
            </Typography>
            <Typography variant="body2" color="text.secondary">
                {crash.on_street_name}
            </Typography>
            <Typography gutterBottom variant="h5" component="div">
                Vehicle Type Code 1
            </Typography>
            <Typography variant="body2" color="text.secondary">
                {crash.vehicle_type_code}
            </Typography>
            <Typography gutterBottom variant="h5" component="div">
                Vehicle Type Code 2
            </Typography>
            <Typography variant="body2" color="text.secondary">
                {crash.vehicle_type_code2}
            </Typography>
        </div>
    )
}

export default crashInfo

// collision_id: "4407480"
// contributing_factor_vehicle_1: "Following Too Closely"
// contributing_factor_vehicle_2: "Unspecified"
// crash_date: "2021-04-14T00:00:00.000"
// crash_time: "5:32"
// number_of_cyclist_injured: "0"
// number_of_cyclist_killed: "0"
// number_of_motorist_injured: "0"
// number_of_motorist_killed: "0"
// number_of_pedestrians_injured: "0"
// number_of_pedestrians_killed: "0"
// number_of_persons_injured: "0"
// number_of_persons_killed: "0"
// on_street_name: "BRONX WHITESTONE BRIDGE"
// vehicle_type_code1: "Sedan"
// vehicle_type_code2: "Sedan"
